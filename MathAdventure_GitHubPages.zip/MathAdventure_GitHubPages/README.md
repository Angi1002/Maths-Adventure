# Math Adventure — GitHub Pages

This folder contains the web version of Math Adventure.

## Publish with GitHub Pages

1. Create a new GitHub repository, for example `math-adventure`.
2. Upload `index.html` from this folder to the repository.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/ (root)**, then save.
6. Your game will be available at:

`https://YOUR-USERNAME.github.io/math-adventure/`

Replace `YOUR-USERNAME` with your GitHub username.

The game is a standalone HTML file, so no Node.js or build command is required.
