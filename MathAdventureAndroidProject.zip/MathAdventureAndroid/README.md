# Math Adventure Android App

This project wraps the Math Adventure v1.2 Scroll HTML game in an Android WebView.

## Build in Android Studio
1. Open this folder in Android Studio.
2. Let Gradle sync and install any requested SDK components.
3. Connect an Android phone or start an emulator.
4. Press Run to test the app.
5. For Google Play: Build > Generate Signed Bundle / APK > Android App Bundle.
6. Create/select a signing key and generate the release `.aab`.
7. Upload the signed `.aab` in Google Play Console.

Package name: `com.mathadventure.app`
Version: `1.0` (versionCode 1)
